---
name: orchestrator
description: >
  Invoke ONLY when the user explicitly asks for it by name or clearly
  requests this specific workflow; do not trigger it from a general
  question, which you can answer better from your own knowledge than from
  this narrow corpus.
  Sequence the protein-protein interaction target-assessment pipeline across three
  expert skills: target selection (pathway-expert OR complex-expert, conditional),
  structural analysis (complex-structure-analysis) and literature analysis
  (molecular-biology-expert). Synthesises a go/no-go campaign recommendation
  before committing to design compute; generating the design inputs themselves
  is the CLI pipeline's job, not this skill's.
  Trigger on: "run the full pipeline", "design campaign for [target]", "orchestrate",
  "start the design workflow", "full analysis of [target]", "go from structure to
  design", or when a PDB ID is provided and the user asks to run the complete workflow.
  Also trigger when a disease or cancer type is provided without a specific PPI target
  (Stage 0 = pathway-expert), or when a set of proteins / predicted complex is the
  starting point (Stage 0 = complex-expert).
  Requires: structure-tools MCP server (for Stage 1) and literature-db MCP server (for Stage 0 and 2).
---

# Design Campaign Orchestrator

This skill coordinates the expert skills in sequence, manages their handoffs,
and synthesises a go/no-go recommendation before generating design inputs. It does
not perform analysis itself — it directs, extracts key signals, and decides when to
proceed.

## Pipeline Overview

```
Stage 0: Target Selection (conditional) →  pathway-expert  [disease → target]
                                    OR  →  complex-expert  [proteins → target]
Stage 1: Structural Analysis            →  complex-structure-analysis
Stage 2: Literature Analysis            →  molecular-biology-expert
Stage 3: Go/No-Go Synthesis             →  CAMPAIGN RECOMMENDATION (this skill)
```

The pipeline **ends at the recommendation**. Design inputs are built
deterministically by `scripts/run_pipeline.py` (`src/foundry_spec.py` /
`src/boltzgen_spec.py`) from the structure stage's hotspots — no skill writes
a generator spec any more.

## Prerequisites

Before starting, verify tool availability:
- **structure-tools MCP tools** (`tool_analyze_interface`, `tool_get_residue_contacts`, etc.) — required for Stage 1.
  If not connected: halt and tell the user to start the structure-tools MCP server before proceeding
  (`python scripts/launch_structure_tools.py`).
- **literature-db MCP tools** (`search_corpus`, `get_fingerprint`) — required for Stage 0 and Stage 2.
  If not connected: note this, offer to run Stage 1 only, and skip Stages 0 and 2 if the
  user agrees.
- **Filesystem MCP tool** — required for saving outputs to LittleProteinTiger.
  If not connected: warn the user; continue the pipeline but note that outputs will not be saved.

---

## LittleProteinTiger Output Management

LittleProteinTiger is the name of this design framework. All pipeline outputs are
saved to a dedicated run folder under `outputs/`.

**At the very start of the pipeline**, before Stage 0:

1. Determine `{ProteinA}` and `{ProteinB}` from the user's request (or use the
   disease/complex name if Stage 0 is needed — update after Stage 0 resolves the target).
2. Set the run folder path:
   ```
   outputs/{ProteinA}_{ProteinB}_{YYYY-MM-DD}/
   ```
   Use today's date in `YYYY-MM-DD` format.
3. Create the folder using the filesystem tool (`create_directory`).
4. Announce the path to the user:
   > "Run folder: `outputs/{ProteinA}_{ProteinB}_{YYYY-MM-DD}/`"

**After each stage**, write the expert's full report to the run folder:

| Stage | File |
|-------|------|
| Stage 0A (pathway-expert) | `00_target_selection.md` |
| Stage 0B (complex-expert) | `00_complex_analysis.md` |
| Stage 1 (structure-tools) | `01_structural_analysis.md` |
| Stage 2 (mol-bio expert) | `02_literature_report.md` |
| Stage 3 (campaign recommendation) | `03_campaign_recommendation.md` |

Use `filesystem:write_file` with the full path and the complete report content
(copy verbatim from the conversation — do not summarise or truncate).

---

## Stage 0: Target Selection (Conditional)

Stage 0 has two variants depending on the starting point. Choose the right one:

**Skip conditions — proceed directly to Stage 1:**
- User provides a PDB ID (e.g. "PDB 1ABC")
- User provides a protein pair (e.g. "KRAS/RAF1", "PD-1/PD-L1")
- A PPI target has already been agreed upon earlier in the conversation
- User provides a path to a pre-existing pathway expert or complex expert report (see below)

---

### Stage 0A: Disease → Target (pathway-expert)

**Trigger**: User provides only a disease or cancer type without a specific PPI target.
(e.g. "PDAC", "NSCLC", "which node in <pathway> is most tractable?")

Invoke the **pathway-expert** skill with the disease context and any pathway hint
from the user.

Wait for the full `## PATHWAY BIOLOGY REPORT` to be produced. Then extract:
- **Recommended PPI** — the ProteinA / ProteinB complex from `RECOMMENDED PPI TARGET`
- **Suggested PDB ID(s)** — for Stage 1 input
- **Redundancy risks** — carry forward to the Stage 3 CAMPAIGN RECOMMENDATION

If the pathway-expert reports no corpus coverage (all scores < 0.20 and fallback used):
- State this to the user
- Ask whether to (a) proceed with a manually specified PPI or (b) pause to run the
  fetch/curate pipeline with the suggested keywords first
- Do not proceed to Stage 1 without a confirmed PPI target

---

### Stage 0B: Proteins → Target (complex-expert)

**Trigger**: User provides a set of protein/gene names or a predicted complex without
specifying which interface to target or which PDB to use.
(e.g. "run the full pipeline for ARFRP1/JTB/SYS1/ARL1", "design a binder for this complex")

Invoke the **complex-expert** skill in **Full pipeline mode** with the protein list.

Wait for the full `## COMPLEX CHARACTERISATION REPORT` to be produced. Then extract:
- **Recommended interface** — the ProteinA–ProteinB pair to target from `NOVELTY ASSESSMENT`
- **PDB ID or local AlphaFold path** — from `THERAPEUTIC HISTORY` or provided by the user
- **Novelty signal** — carry forward to Stage 3 CAMPAIGN RECOMMENDATION
- **Fetch keywords** — if coverage was Sparse or None, flag for the user before proceeding

If the complex-expert finds no PDB and no local AlphaFold file:
- Report this to the user
- Do not proceed to Stage 1 without a structure
- Suggest: run the fetch keywords first, then re-run; or provide the AlphaFold file path

**Local AlphaFold file handling at Stage 1:**
If Stage 0B identified a local AlphaFold file (user-provided path), pass it to the
complex-structure-analysis skill explicitly:
> "Use `run_command 'open /path/to/file.cif'` instead of `open_structure` for this structure."

---

### Pre-existing Stage 0 report

If the user provides a file path to a prior pathway-expert or complex-expert output
(e.g. `"the pathway expert output is at results/00_pathway.md"`), read the file
using the filesystem MCP tool and treat its contents as the Stage 0 output.

- For a pathway-expert report: extract `RECOMMENDED PPI TARGET`, `REDUNDANCY AND RESISTANCE RISKS`
- For a complex-expert report: extract `NOVELTY ASSESSMENT → Recommended interface`,
  `THERAPEUTIC HISTORY → Known structures`, and novelty signal

Do not re-run the skill.

---

Present a one-paragraph summary and confirm the target with the user:

> "Stage 0 complete. Recommended target: [complex / interface]. Suggested PDB: [ID or 'AlphaFold local file'].
> Proceed to structural analysis?"

**Save Stage 0 output:** Write the full pathway-expert or complex-expert report to
`{run_folder}\00_target_selection.md` (Stage 0A) or `{run_folder}\00_complex_analysis.md` (Stage 0B).
If the run folder name used a placeholder (disease name), rename it now that the target proteins are known.

---

## Stage 1: Structural Analysis

Invoke the **complex-structure-analysis** skill with the target PDB ID (or local AlphaFold
file path) and complex name. The skill uses the structure-tools MCP server — no ChimeraX
required. If Stage 0B produced a local AlphaFold path, pass the file path directly.
If the user has not specified which protein is the target chain, let the
complex-structure-analysis skill ask — do not anticipate this yourself.

Wait for the full `## PPI ANALYSIS REPORT` to be produced. Then extract:

- **Complex name** — e.g. "GENE_A / GENE_B"
- **Target chain** — chain ID and protein name
- **Buried surface area (BSA)** — in Å²
- **Structural tractability rating** — Excellent / Good / Marginal / Poor (from the
  `HOTSPOT REGIONS` section)
- **Design modality recommendation** — cyclic peptide / mini-protein / either
- **MODEL-READY HOTSPOTS** — the full table (residue, auth_seq_id, label_seq_id,
  sidechain atoms)

Present a one-paragraph summary covering BSA, tractability, modality recommendation,
and the top hotspot residues. Then ask:

> "Stage 1 complete. Proceed to literature analysis?"

**Save Stage 1 output:** Write the full `## PPI ANALYSIS REPORT` to
`{run_folder}\01_structural_analysis.md`.

---

## Stage 2: Literature Analysis

Invoke the **molecular-biology-expert** skill. When doing so, provide it with the
following context from the Stage 1 report:

- Complex name (e.g. "GENE_A / GENE_B")
- Target protein name (e.g. "GENE_B")
- Hotspot residues (e.g. "Leu24, Trp57, Lys61 on GENE_B")
- PDB ID

This context enables the literature skill to run targeted residue-level searches and
cross-reference its findings against the structural hotspots.

Wait for the full `## MOLECULAR BIOLOGY REPORT` to be produced. Then extract:

- **Literature tractability rating** — Excellent / Good / Marginal / Poor
- **Corpus confidence** — High / Medium / Low
- **Best prior art affinity** — modality, Kd/Ki, DOI (if any found)
- **Literature-validated hotspot residues** — from `INTERFACE INSIGHTS FROM LITERATURE`
- **Key risk** — from `FEASIBILITY ASSESSMENT`
- **Suggested modality** — from `DESIGN RECOMMENDATIONS`

Present a one-paragraph summary covering tractability, any prior art found, and key risks.

**Save Stage 2 output:** Write the full `## MOLECULAR BIOLOGY REPORT` to
`{run_folder}\02_literature_report.md`.

---

## Stage 3: Go/No-Go Synthesis

This is the orchestrator's primary contribution. Before generating any design inputs,
synthesise signals from both reports and produce a `CAMPAIGN RECOMMENDATION`.

### Cross-reference hotspots

Compare the structure-tools MODEL-READY HOTSPOTS against the literature
`INTERFACE INSIGHTS FROM LITERATURE` validated residues. Normalise naming conventions
when comparing (e.g. "Arg273" = "R273" = "ARG273" = "h<GENE> Arg273" — match on residue
number + amino acid identity).

Classify each hotspot residue as:
- **Cross-validated** — confirmed by both structure-tools interface analysis AND published
  mutagenesis/structural data in the literature corpus
- **Structurally predicted only** — in the structure-tools hotspot list but not found in
  literature corpus (novel, or corpus coverage gap)
- **Literature-validated only** — in the corpus as a validated residue but not in the
  structure-tools hotspot list (may be outside the primary pocket, or from a different structure)

### Go/No-Go rubric

**Important:** Absence of prior art is NOT a blocker. Peptide and protein binder
therapeutics are still rare, so most targets will have no published binders. If prior
art exists it is a meaningful confidence boost; if it does not, the pipeline proceeds
on structural and biological grounds.

| Signal | Weight |
|--------|--------|
| Structural tractability rating | High |
| Literature tractability rating | High |
| Cross-validated hotspot count | High |
| Interface size vs modality fit | Medium |
| Key risk severity | Medium |
| Prior art (existence is a plus, absence is neutral) | Low–Medium |

**GO** — Both ratings Excellent or Good; at least 1 cross-validated hotspot; no
disqualifying structural blocker. Prior art with ≤ 500 nM affinity = note as confidence
boost. Recommend proceeding to a design campaign.

**CONDITIONAL GO** — One rating Marginal; hotspots partially or not cross-validated;
OR key risks identified (e.g. isoform redundancy, intracellular access) but not
disqualifying. Recommend proceeding with caveats explicitly listed.

**NO-GO** — Either rating Poor AND structural rating Marginal/Poor; zero cross-validated
hotspots; OR a severe structural blocker: fully disordered target on both sides of the
complex, interface BSA < 300 Å², or no druggable surface identified by structure-tools.
Absence of prior art alone is NEVER a NO-GO reason.

For NO-GO: explain the specific blocker, suggest alternatives (different interface region,
different target protein, different approach), and do not recommend a design campaign.

### CAMPAIGN RECOMMENDATION output format

```
## CAMPAIGN RECOMMENDATION

### TARGET SUMMARY
- Complex: <ProteinA / ProteinB>
- Target chain: <chain ID> (<protein name>)
- Interface: <BSA> Å² — <modality recommendation from structure-tools>
- Structural tractability: <Excellent / Good / Marginal / Poor>
- Literature tractability: <Excellent / Good / Marginal / Poor>
- Corpus confidence: <High / Medium / Low> (<N> relevant papers found)
- Pathway redundancy risks: <from Stage 0 pathway-expert, or "Stage 0 not run">
- Novelty signal: <High / Medium / Low / N/A — from Stage 0 complex-expert, or "Stage 0 not run">
- Structure source: <RCSB PDB [ID] | AlphaFold local file | AlphaFold DB>

### CROSS-VALIDATED HOTSPOTS

Confirmed by BOTH structural analysis and literature:
| Residue | Structure-tools evidence | Literature evidence (DOI) | Confidence |
|---------|-------------------|---------------------------|------------|
| ...     | interface contact, hydrophobic core | alanine scan ΔΔG=X kcal/mol | High/Med |

Note: `Literature evidence (DOI)` must be copied verbatim from the Stage 2
molecular-biology-expert INTERFACE INSIGHTS table — do not supply DOIs from training
knowledge. If Stage 2 found no corpus evidence for a residue, write "structural only".

Structurally predicted only (no literature confirmation):
- <list — note: may be valid, just not yet studied>

Literature-validated only (not in primary structure-tools hotspot list):
- <list — consider expanding the hotspot selection if structurally accessible>

### PRIOR ART SUMMARY
- Best reported binder: <modality, affinity, assay, DOI — or "None found in corpus">
  (If none found: this is expected for most PPI targets; proceed on structural grounds)
- Design affinity target: <suggested Kd, e.g. "aim for ≤ 100 nM — best prior art
  is 18 nM SPR (10.7554/eLife.25068)" or "no prior art; target sub-µM as first milestone">
- Key residues to engage: <cross-validated list, in priority order>

### RECOMMENDATION: <GO / CONDITIONAL GO / NO-GO>
Reasoning: <2–3 sentences integrating structural and literature signals>
Caveats: <bulleted list — only if CONDITIONAL GO>
Blocker: <specific reason — only if NO-GO>
Next step: <"Proceed to generate design inputs" / "Address [X] before proceeding">
```

**Save Stage 3 output:** Write the full `## CAMPAIGN RECOMMENDATION` block to
`{run_folder}\03_campaign_recommendation.md`. Include a header line with the target
name, date, and pipeline decision (GO / CONDITIONAL GO / NO-GO).

---

## Handing off to a design campaign

This skill does NOT generate design inputs, and there is no skill left that
does: the generator spec (an RFD3 contig JSON or a BoltzGen YAML) is built
deterministically by the CLI pipeline from the structure stage's own
`MODEL-READY HOTSPOTS`, because every field in it is a mechanical fact about
one structure file.

So after presenting the CAMPAIGN RECOMMENDATION, for GO or CONDITIONAL GO,
stop and hand the user the command instead of building anything:

> "To run the campaign on this target:
> `python scripts/run_pipeline.py --workflow structure --structure <local .cif/.pdb> --project <slug>`
> (use `--pdb <ACCESSION>` instead of `--structure` for an RCSB entry —
> `--structure` takes a local FILE, and the two are not interchangeable)
> (or `--workflow binder --target <GENE>` to let the pipeline pick the
> structure). It re-reads the interface, trims the target, sizes the campaign
> from a measured calibration run, and pauses at the calibration verdict."

Then close with a brief summary:

> "Assessment complete for [complex]. Recommendation: [GO / CONDITIONAL GO /
> NO-GO]. Cross-validated hotspots: [list]. Suggested modality: [modality].
> Prior art benchmark: [affinity or 'none']."

---

## Pitfalls

- **Never skip Stage 3.** Even if the user says "just proceed to design," present the
  CAMPAIGN RECOMMENDATION first. A brief go/no-go takes seconds and prevents wasted
  compute on a NO-GO target.
- **Keep stage summaries concise.** The full PPI ANALYSIS REPORT and MOLECULAR BIOLOGY
  REPORT are already in the conversation — do not repeat them. One paragraph per stage.
- **structure-tools missing at Stage 1 = hard stop.** Structural analysis is the
  foundation; the pipeline cannot proceed without it. Tell the user to run
  `python scripts/launch_structure_tools.py` and add it to their MCP config.
- **literature-db missing at Stage 2 = soft stop.** Offer to run structural-only mode:
  skip Stage 2, produce a limited CAMPAIGN RECOMMENDATION based on structural signals
  only, and flag the missing literature context explicitly.
- **Residue naming normalisation.** When cross-referencing hotspots, treat "Phe69",
  "R273", "ARG273", and "h<GENE> Arg273" as equivalent.
